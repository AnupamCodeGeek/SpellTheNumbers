﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumWords;



namespace Tests
{
    [TestClass]
    public class NumbertoWordConverterTest
    {
        [TestMethod]
        public void NumberToWordTest1()
        {
           var word =  NumbertoWordConverter.NumWords(456);
            Assert.AreEqual(word, "four hundred fifty-six");
           

        }
        [TestMethod]
        public void NumberToWordTest2()
        {
            var word = NumbertoWordConverter.NumWords(776666666);
            Assert.AreEqual(word, "seven hundred seventy-six million, six hundred sixty-six thousand, six hundred sixty-six");


        }
      
    }
}
