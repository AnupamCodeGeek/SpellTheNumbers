﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace NumWords
{
    class Program
    {


        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter a number to convert to words: ");
                Double n = Double.Parse(Console.ReadLine());

                Console.WriteLine("{0}", NumbertoWordConverter.NumWordsWrapper(n));
                Console.ReadLine();
            }
            catch (Exception exeption)
            {
                Console.WriteLine(exeption.Message + "Press Enter to exit");
                Console.ReadLine();

            }
        }
    }
}